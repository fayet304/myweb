import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

const positions = [
  'Software Engineer',
  'Frontend Developer',
  'Backend Developer',
  'UI/UX Designer',
  'Product Manager',
  'Data Analyst',
  'DevOps Engineer',
  'Marketing Manager',
  'HR Manager',
  'Finance Analyst',
  'Project Manager',
  'QA Engineer',
  'Mobile Developer',
  'Business Analyst',
  'Content Writer'
];

const firstNames = [
  'Ahmad', 'Budi', 'Citra', 'Dewi', 'Eko', 'Fitri', 'Gunawan', 'Hana', 'Irfan', 'Joko',
  'Kartika', 'Linda', 'Muhammad', 'Nadia', 'Oscar', 'Putri', 'Rizki', 'Sari', 'Toni', 'Umi',
  'Vina', 'Wahyu', 'Xena', 'Yudi', 'Zahra', 'Andi', 'Bella', 'Chandra', 'Diana', 'Eka',
  'Fajar', 'Gita', 'Hendra', 'Indah', 'Jasmine', 'Kiki', 'Lukman', 'Maya', 'Niko', 'Olivia',
  'Pandu', 'Qonita', 'Rendi', 'Shinta', 'Teguh', 'Ulya', 'Vina', 'Wulan', 'Yoga', 'Zaki'
];

const lastNames = [
  'Pratama', 'Sari', 'Wijaya', 'Kusuma', 'Hidayat', 'Putra', 'Dewantara', 'Santoso',
  'Permana', 'Nugraha', 'Ramadhan', 'Setiawan', 'Wibowo', 'Saputra', 'Purnama',
  'Cahyono', 'Firmansyah', 'Rahayu', 'Susanto', 'Handoko', 'Wibisono', 'Pangestu',
  'Gunawan', 'Sutanto', 'Lim', 'Wong', 'Chen', 'Tanaka', 'Kim', 'Park'
];

const statusOptions = ['hadir', 'hadir', 'hadir', 'hadir', 'izin', 'sakit', 'alpa'];

function generatePhone(): string {
  const prefix = ['0812', '0813', '0821', '0822', '0856', '0857', '0878', '0896'][Math.floor(Math.random() * 8)];
  return prefix + Math.floor(Math.random() * 100000000).toString().padStart(8, '0');
}

function getRandomDate(start: Date, end: Date): Date {
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function formatDate(date: Date): string {
  return date.toISOString().split('T')[0];
}

function getRandomTime(baseHour: number, variance: number): Date {
  const hour = baseHour + Math.floor(Math.random() * variance) - Math.floor(variance / 2);
  const minute = Math.floor(Math.random() * 60);
  const date = new Date();
  date.setHours(hour, minute, 0, 0);
  return date;
}

async function main() {
  console.log('Starting seed...');

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@company.com' },
    update: {},
    create: {
      email: 'admin@company.com',
      password: adminPassword,
      name: 'Admin Utama',
      role: 'admin',
      phone: '081234567890',
      position: 'Administrator',
      isActive: true,
    },
  });
  console.log('Created admin:', admin.email);

  // Create 50 employees
  const employees = [];
  for (let i = 0; i < 50; i++) {
    const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
    const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
    const name = `${firstName} ${lastName}`;
    const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${i}@company.com`;
    const password = await bcrypt.hash('password123', 10);
    
    const employee = await prisma.user.create({
      data: {
        email,
        password,
        name,
        role: 'employee',
        phone: generatePhone(),
        position: positions[Math.floor(Math.random() * positions.length)],
        isActive: true,
      },
    });
    employees.push(employee);
    console.log(`Created employee ${i + 1}: ${name}`);
  }

  // Create attendance records for the past 30 days
  const today = new Date();
  const thirtyDaysAgo = new Date(today);
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  for (const employee of employees) {
    for (let d = new Date(thirtyDaysAgo); d <= today; d.setDate(d.getDate() + 1)) {
      // Skip weekends
      if (d.getDay() === 0 || d.getDay() === 6) continue;

      const status = statusOptions[Math.floor(Math.random() * statusOptions.length)];
      let checkIn: Date | null = null;
      let checkOut: Date | null = null;
      let workHours: number | null = null;

      if (status === 'hadir') {
        checkIn = getRandomTime(8, 2); // Between 7-9 AM
        checkOut = getRandomTime(17, 2); // Between 4-6 PM
        workHours = 8 + (Math.random() * 2 - 1); // 7-9 hours
      }

      await prisma.attendance.create({
        data: {
          userId: employee.id,
          date: new Date(d),
          checkIn,
          checkOut,
          status,
          workHours,
          note: status !== 'hadir' ? ['Keperluan pribadi', 'Sakit demam', 'Urusan keluarga', ''][Math.floor(Math.random() * 4)] : null,
        },
      });
    }
    console.log(`Created attendance for: ${employee.name}`);
  }

  // Create some attendance for today
  for (const employee of employees.slice(0, 35)) {
    const existingAttendance = await prisma.attendance.findFirst({
      where: {
        userId: employee.id,
        date: {
          gte: new Date(today.setHours(0, 0, 0, 0)),
        },
      },
    });

    if (!existingAttendance) {
      const checkIn = getRandomTime(8, 2);
      const hasCheckedOut = Math.random() > 0.5;
      
      await prisma.attendance.create({
        data: {
          userId: employee.id,
          date: new Date(),
          checkIn,
          checkOut: hasCheckedOut ? getRandomTime(17, 2) : null,
          status: 'hadir',
          workHours: hasCheckedOut ? 8 + (Math.random() * 2 - 1) : null,
        },
      });
    }
  }

  console.log('Seed completed!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
