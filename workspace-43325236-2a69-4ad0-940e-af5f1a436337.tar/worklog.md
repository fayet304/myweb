# AttendX - Sistem Absensi Premium Dashboard

## Ringkasan Proyek

Dashboard absensi premium dengan desain modern glassmorphism yang memiliki fitur lengkap untuk mengelola kehadiran karyawan.

### Fitur Utama

1. **Autentikasi Multi-Role**
   - Login untuk Admin dan Karyawan
   - Password hashing dengan bcryptjs
   - Session management dengan Zustand persist

2. **Dashboard Admin**
   - Statistik kehadiran real-time
   - Grafik kehadiran (Area, Pie, Bar)
   - Daftar karyawan dengan pencarian dan filter
   - Rekap absensi dengan filter tanggal dan status
   - Export data ke CSV

3. **Dashboard Karyawan**
   - Check In / Check Out
   - Riwayat kehadiran pribadi
   - Status absensi real-time

4. **Fitur Tambahan**
   - Dark Mode / Light Mode toggle
   - Responsive design
   - Glassmorphism UI design
   - Animasi dengan Framer Motion

### Akun Demo

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@company.com | admin123 |
| Karyawan | vina.nugraha0@company.com | password123 |

### Teknologi Stack

- **Frontend**: Next.js 16, React 19, TypeScript
- **Styling**: Tailwind CSS 4, shadcn/ui
- **State Management**: Zustand
- **Database**: Prisma ORM + SQLite
- **Charts**: Recharts
- **Animations**: Framer Motion
- **Icons**: Lucide React

### Struktur File

```
src/
├── app/
│   ├── api/
│   │   ├── auth/
│   │   │   ├── login/route.ts
│   │   │   └── logout/route.ts
│   │   ├── attendance/route.ts
│   │   ├── stats/route.ts
│   │   └── users/route.ts
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── dashboard/
│   │   ├── login-form.tsx
│   │   ├── sidebar.tsx
│   │   ├── header.tsx
│   │   ├── stats-cards.tsx
│   │   ├── attendance-chart.tsx
│   │   ├── employee-table.tsx
│   │   ├── attendance-table.tsx
│   │   ├── check-in-out.tsx
│   │   └── dashboard-content.tsx
│   └── ui/ (shadcn components)
├── store/
│   └── auth-store.ts
└── lib/
    ├── db.ts
    └── utils.ts

prisma/
├── schema.prisma
└── seed.ts
```

### Cara Menjalankan

1. Development server otomatis berjalan di port 3000
2. Buka Preview Panel di sebelah kanan
3. Login dengan akun demo di atas

### Catatan Penting

- Semua fitur berjalan dengan normal
- Database sudah terisi dengan 50 karyawan dummy
- Data absensi 30 hari terakhir sudah tersedia
- Export CSV berfungsi dengan baik
