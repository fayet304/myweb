'use client';

import { useAuthStore } from '@/store/auth-store';
import { LoginForm } from '@/components/dashboard/login-form';
import { DashboardContent } from '@/components/dashboard/dashboard-content';
import { useState } from 'react';

export default function Home() {
  const { isAuthenticated } = useAuthStore();
  const [mounted] = useState(true);

  if (!mounted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  return <DashboardContent />;
}
