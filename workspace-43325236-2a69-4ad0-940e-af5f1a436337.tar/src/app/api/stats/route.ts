import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get('period') || 'weekly';

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let startDate = new Date();
    if (period === 'weekly') {
      startDate.setDate(today.getDate() - 7);
    } else if (period === 'monthly') {
      startDate.setMonth(today.getMonth() - 1);
    } else {
      startDate.setDate(today.getDate() - 30);
    }

    // Get total employees
    const totalEmployees = await db.user.count({
      where: { role: 'employee', isActive: true },
    });

    // Get today's attendance
    const todayAttendance = await db.attendance.findMany({
      where: {
        date: {
          gte: today,
        },
      },
    });

    const presentToday = todayAttendance.filter((a) => a.status === 'hadir').length;
    const lateToday = todayAttendance.filter((a) => {
      if (!a.checkIn) return false;
      const checkInHour = new Date(a.checkIn).getHours();
      return checkInHour >= 9;
    }).length;

    // Get attendance stats for period
    const attendanceStats = await db.attendance.groupBy({
      by: ['status'],
      where: {
        date: {
          gte: startDate,
          lte: today,
        },
      },
      _count: true,
    });

    // Get daily attendance for chart
    const dailyAttendance = await db.attendance.findMany({
      where: {
        date: {
          gte: startDate,
          lte: today,
        },
      },
      orderBy: {
        date: 'asc',
      },
    });

    // Group by date
    const dailyStats = dailyAttendance.reduce((acc, curr) => {
      const dateKey = new Date(curr.date).toISOString().split('T')[0];
      if (!acc[dateKey]) {
        acc[dateKey] = {
          date: dateKey,
          hadir: 0,
          izin: 0,
          sakit: 0,
          alpa: 0,
        };
      }
      acc[dateKey][curr.status as keyof typeof acc[string]]++;
      return acc;
    }, {} as Record<string, any>);

    // Get average work hours
    const workHoursData = await db.attendance.findMany({
      where: {
        date: {
          gte: startDate,
          lte: today,
        },
        workHours: { not: null },
      },
      select: { workHours: true },
    });

    const avgWorkHours = workHoursData.length > 0
      ? workHoursData.reduce((sum, a) => sum + (a.workHours || 0), 0) / workHoursData.length
      : 0;

    // Department stats
    const departmentStats = await db.user.groupBy({
      by: ['position'],
      where: { role: 'employee', isActive: true },
      _count: true,
    });

    const stats = {
      totalEmployees,
      presentToday,
      lateToday,
      absentToday: totalEmployees - presentToday,
      attendanceByStatus: attendanceStats.reduce((acc, curr) => {
        acc[curr.status] = curr._count;
        return acc;
      }, {} as Record<string, number>),
      dailyStats: Object.values(dailyStats),
      avgWorkHours: Math.round(avgWorkHours * 10) / 10,
      departmentStats: departmentStats
        .filter(d => d.position)
        .map(d => ({ name: d.position, value: d._count })),
    };

    return NextResponse.json(stats);
  } catch (error) {
    console.error('Get stats error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
