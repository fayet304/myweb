import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const startDate = searchParams.get('startDate');
    const endDate = searchParams.get('endDate');
    const status = searchParams.get('status');
    const search = searchParams.get('search');

    const where: any = {};

    if (userId) {
      where.userId = userId;
    }

    if (startDate && endDate) {
      where.date = {
        gte: new Date(startDate),
        lte: new Date(endDate),
      };
    }

    if (status && status !== 'all') {
      where.status = status;
    }

    const attendances = await db.attendance.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            position: true,
            phone: true,
          },
        },
      },
      orderBy: {
        date: 'desc',
      },
    });

    let filteredAttendances = attendances;
    if (search) {
      const searchLower = search.toLowerCase();
      filteredAttendances = attendances.filter(
        (a) =>
          a.user.name.toLowerCase().includes(searchLower) ||
          a.user.email.toLowerCase().includes(searchLower) ||
          a.user.position?.toLowerCase().includes(searchLower)
      );
    }

    return NextResponse.json(filteredAttendances);
  } catch (error) {
    console.error('Get attendance error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { userId, status, note, checkIn, checkOut } = body;

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Check if attendance already exists for today
    const existingAttendance = await db.attendance.findFirst({
      where: {
        userId,
        date: {
          gte: today,
        },
      },
    });

    if (existingAttendance) {
      // Update existing attendance
      const updateData: any = {};
      
      if (checkIn) {
        updateData.checkIn = new Date(checkIn);
      }
      if (checkOut) {
        updateData.checkOut = new Date(checkOut);
        // Calculate work hours
        if (existingAttendance.checkIn || updateData.checkIn) {
          const checkInTime = existingAttendance.checkIn || updateData.checkIn;
          const checkOutTime = new Date(checkOut);
          const diffMs = checkOutTime.getTime() - checkInTime.getTime();
          updateData.workHours = Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100;
        }
      }
      if (status) {
        updateData.status = status;
      }
      if (note !== undefined) {
        updateData.note = note;
      }

      const updated = await db.attendance.update({
        where: { id: existingAttendance.id },
        data: updateData,
        include: {
          user: {
            select: {
              id: true,
              name: true,
              email: true,
              position: true,
            },
          },
        },
      });

      return NextResponse.json(updated);
    }

    // Create new attendance
    const attendance = await db.attendance.create({
      data: {
        userId,
        date: new Date(),
        checkIn: checkIn ? new Date(checkIn) : new Date(),
        status: status || 'hadir',
        note,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            position: true,
          },
        },
      },
    });

    return NextResponse.json(attendance);
  } catch (error) {
    console.error('Create attendance error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}

export async function PUT(request: Request) {
  try {
    const body = await request.json();
    const { id, status, note, checkIn, checkOut } = body;

    const updateData: any = {};
    
    if (checkIn !== undefined) {
      updateData.checkIn = checkIn ? new Date(checkIn) : null;
    }
    if (checkOut !== undefined) {
      updateData.checkOut = checkOut ? new Date(checkOut) : null;
    }
    if (status) {
      updateData.status = status;
    }
    if (note !== undefined) {
      updateData.note = note;
    }

    // Recalculate work hours if needed
    if (updateData.checkIn || updateData.checkOut) {
      const current = await db.attendance.findUnique({ where: { id } });
      if (current) {
        const checkInTime = updateData.checkIn ?? current.checkIn;
        const checkOutTime = updateData.checkOut ?? current.checkOut;
        if (checkInTime && checkOutTime) {
          const diffMs = new Date(checkOutTime).getTime() - new Date(checkInTime).getTime();
          updateData.workHours = Math.round((diffMs / (1000 * 60 * 60)) * 100) / 100;
        }
      }
    }

    const updated = await db.attendance.update({
      where: { id },
      data: updateData,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
            position: true,
          },
        },
      },
    });

    return NextResponse.json(updated);
  } catch (error) {
    console.error('Update attendance error:', error);
    return NextResponse.json(
      { error: 'Terjadi kesalahan pada server' },
      { status: 500 }
    );
  }
}
