'use client';

import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore, User } from '@/store/auth-store';
import { Sidebar } from './sidebar';
import { Header } from './header';
import { StatsCards } from './stats-cards';
import { AttendanceChart } from './attendance-chart';
import { EmployeeTable } from './employee-table';
import { AttendanceTable } from './attendance-table';
import { CheckInOut } from './check-in-out';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Download, FileSpreadsheet, FileText, RefreshCw } from 'lucide-react';
import { toast } from 'sonner';

interface Stats {
  totalEmployees: number;
  presentToday: number;
  lateToday: number;
  absentToday: number;
  avgWorkHours: number;
  attendanceByStatus: Record<string, number>;
  dailyStats: Array<{
    date: string;
    hadir: number;
    izin: number;
    sakit: number;
    alpa: number;
  }>;
  departmentStats: Array<{ name: string; value: number }>;
}

interface Employee {
  id: string;
  name: string;
  email: string;
  position: string | null;
  phone: string | null;
  role: string;
  isActive: boolean;
}

interface AttendanceRecord {
  id: string;
  userId: string;
  date: string;
  checkIn: string | null;
  checkOut: string | null;
  status: string;
  note: string | null;
  workHours: number | null;
  user: {
    id: string;
    name: string;
    email: string;
    position: string | null;
  };
}

export function DashboardContent() {
  const { user } = useAuthStore();
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState<Stats | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [todayAttendance, setTodayAttendance] = useState<AttendanceRecord | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState('weekly');

  const isAdmin = user?.role === 'admin';

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [statsRes, employeesRes, attendanceRes] = await Promise.all([
        fetch(`/api/stats?period=${period}`),
        fetch('/api/users'),
        fetch('/api/attendance'),
      ]);

      const statsData = await statsRes.json();
      const employeesData = await employeesRes.json();
      const attendanceData = await attendanceRes.json();

      setStats(statsData);
      setEmployees(employeesData.filter((e: Employee) => e.role === 'employee'));
      setAttendance(attendanceData);

      // Find today's attendance for current user
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayRecord = attendanceData.find(
        (a: AttendanceRecord) => a.userId === user?.id && new Date(a.date) >= today
      );
      setTodayAttendance(todayRecord);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Gagal memuat data');
    } finally {
      setLoading(false);
    }
  }, [period, user?.id]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleCheckIn = async () => {
    if (!user) return;
    try {
      const res = await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.id, status: 'hadir' }),
      });
      const data = await res.json();
      setTodayAttendance(data);
      toast.success('Check in berhasil!');
      fetchData();
    } catch (error) {
      toast.error('Gagal check in');
    }
  };

  const handleCheckOut = async () => {
    if (!user || !todayAttendance) return;
    try {
      const res = await fetch('/api/attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          userId: user.id, 
          checkOut: new Date().toISOString() 
        }),
      });
      const data = await res.json();
      setTodayAttendance(data);
      toast.success('Check out berhasil!');
      fetchData();
    } catch (error) {
      toast.error('Gagal check out');
    }
  };

  const handleUpdateAttendance = async (id: string, data: any) => {
    try {
      const res = await fetch('/api/attendance', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, ...data }),
      });
      if (res.ok) {
        toast.success('Absensi berhasil diperbarui');
        fetchData();
      }
    } catch (error) {
      toast.error('Gagal memperbarui absensi');
    }
  };

  const handleExport = async (format: 'csv' | 'pdf') => {
    try {
      const data = attendance.map(a => ({
        Nama: a.user.name,
        Tanggal: new Date(a.date).toLocaleDateString('id-ID'),
        Masuk: a.checkIn ? new Date(a.checkIn).toLocaleTimeString('id-ID') : '-',
        Keluar: a.checkOut ? new Date(a.checkOut).toLocaleTimeString('id-ID') : '-',
        Status: a.status,
        Jam_Kerja: a.workHours || '-',
      }));

      if (format === 'csv') {
        const headers = Object.keys(data[0] || {}).join(',');
        const rows = data.map(row => Object.values(row).join(',')).join('\n');
        const csv = `${headers}\n${rows}`;
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `absensi_${new Date().toISOString().split('T')[0]}.csv`;
        a.click();
        toast.success('CSV berhasil diunduh');
      }
    } catch (error) {
      toast.error('Gagal mengekspor data');
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <div className="space-y-6">
            {/* Check In/Out for Employee */}
            {!isAdmin && (
              <CheckInOut
                userId={user?.id || ''}
                todayAttendance={todayAttendance}
                onCheckIn={handleCheckIn}
                onCheckOut={handleCheckOut}
              />
            )}

            {/* Stats Cards */}
            {stats && <StatsCards stats={stats} />}

            {/* Charts */}
            {stats && (
              <AttendanceChart
                dailyStats={stats.dailyStats}
                attendanceByStatus={stats.attendanceByStatus}
                departmentStats={stats.departmentStats}
              />
            )}

            {/* Recent Attendance */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Absensi Terbaru</h3>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={fetchData}
                  className="text-gray-400 hover:text-white"
                >
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh
                </Button>
              </div>
              <AttendanceTable
                attendance={attendance.slice(0, 10)}
                onUpdate={handleUpdateAttendance}
                isAdmin={isAdmin}
              />
            </div>
          </div>
        );

      case 'employees':
        return (
          <div className="space-y-6">
            <EmployeeTable employees={employees} />
          </div>
        );

      case 'attendance':
        return (
          <div className="space-y-6">
            {/* Check In/Out for Employee */}
            {!isAdmin && (
              <CheckInOut
                userId={user?.id || ''}
                todayAttendance={todayAttendance}
                onCheckIn={handleCheckIn}
                onCheckOut={handleCheckOut}
              />
            )}
            <AttendanceTable
              attendance={attendance}
              onUpdate={handleUpdateAttendance}
              onExport={() => handleExport('csv')}
              isAdmin={isAdmin}
            />
          </div>
        );

      case 'reports':
        return (
          <div className="space-y-6">
            {/* Period Filter */}
            <div className="flex items-center gap-4">
              <Tabs value={period} onValueChange={setPeriod}>
                <TabsList className="bg-white/5 border border-white/10">
                  <TabsTrigger value="weekly" className="data-[state=active]:bg-purple-500/30 data-[state=active]:text-white">
                    Mingguan
                  </TabsTrigger>
                  <TabsTrigger value="monthly" className="data-[state=active]:bg-purple-500/30 data-[state=active]:text-white">
                    Bulanan
                  </TabsTrigger>
                </TabsList>
              </Tabs>

              <div className="flex gap-2 ml-auto">
                <Button
                  onClick={() => handleExport('csv')}
                  variant="outline"
                  className="bg-white/5 border-white/10 text-white hover:bg-white/10"
                >
                  <FileSpreadsheet className="w-4 h-4 mr-2" />
                  Export CSV
                </Button>
                <Button
                  onClick={() => handleExport('pdf')}
                  variant="outline"
                  className="bg-white/5 border-white/10 text-white hover:bg-white/10"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Export PDF
                </Button>
              </div>
            </div>

            {/* Stats Cards */}
            {stats && <StatsCards stats={stats} />}

            {/* Charts */}
            {stats && (
              <AttendanceChart
                dailyStats={stats.dailyStats}
                attendanceByStatus={stats.attendanceByStatus}
                departmentStats={stats.departmentStats}
              />
            )}

            {/* Full Attendance Table */}
            <AttendanceTable
              attendance={attendance}
              onUpdate={handleUpdateAttendance}
              onExport={() => handleExport('csv')}
              isAdmin={isAdmin}
            />
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />
      
      <div className="ml-64 transition-all duration-300">
        <Header />
        
        <main className="p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.3 }}
            >
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="w-8 h-8 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
                </div>
              ) : (
                renderContent()
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
