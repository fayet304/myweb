'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { 
  Clock, 
  LogIn, 
  LogOut, 
  Calendar,
  CheckCircle,
  AlertCircle,
  Timer
} from 'lucide-react';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

interface CheckInOutProps {
  userId: string;
  todayAttendance: {
    id: string;
    checkIn: string | null;
    checkOut: string | null;
    status: string;
  } | null;
  onCheckIn: () => void;
  onCheckOut: () => void;
}

export function CheckInOut({ userId, todayAttendance, onCheckIn, onCheckOut }: CheckInOutProps) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleCheckIn = async () => {
    setLoading(true);
    try {
      await onCheckIn();
    } finally {
      setLoading(false);
    }
  };

  const handleCheckOut = async () => {
    setLoading(true);
    try {
      await onCheckOut();
    } finally {
      setLoading(false);
    }
  };

  const isCheckedIn = todayAttendance?.checkIn;
  const isCheckedOut = todayAttendance?.checkOut;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.2 }}
      className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-6"
    >
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-white">Absensi Hari Ini</h3>
        <div className="flex items-center gap-2 text-gray-400">
          <Calendar className="w-4 h-4" />
          <span className="text-sm">
            {format(new Date(), 'EEEE, d MMMM yyyy', { locale: id })}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Current Time */}
        <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
          <CardContent className="p-4 text-center">
            <Timer className="w-8 h-8 text-cyan-400 mx-auto mb-3" />
            <p className="text-gray-400 text-sm mb-1">Waktu Sekarang</p>
            <p className="text-3xl font-bold text-white font-mono">
              {format(currentTime, 'HH:mm:ss')}
            </p>
          </CardContent>
        </Card>

        {/* Check In Status */}
        <Card className={`bg-white/5 border backdrop-blur-sm ${isCheckedIn ? 'border-emerald-500/30' : 'border-white/10'}`}>
          <CardContent className="p-4 text-center">
            {isCheckedIn ? (
              <>
                <CheckCircle className="w-8 h-8 text-emerald-400 mx-auto mb-3" />
                <p className="text-gray-400 text-sm mb-1">Check In</p>
                <p className="text-2xl font-bold text-white">
                  {format(new Date(isCheckedIn), 'HH:mm')}
                </p>
                <p className="text-emerald-400 text-xs mt-1">Sudah check in</p>
              </>
            ) : (
              <>
                <LogIn className="w-8 h-8 text-amber-400 mx-auto mb-3" />
                <p className="text-gray-400 text-sm mb-1">Check In</p>
                <p className="text-gray-500">--:--</p>
                <Button
                  onClick={handleCheckIn}
                  disabled={loading}
                  className="mt-3 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white"
                >
                  {loading ? 'Memproses...' : 'Check In'}
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {/* Check Out Status */}
        <Card className={`bg-white/5 border backdrop-blur-sm ${isCheckedOut ? 'border-rose-500/30' : 'border-white/10'}`}>
          <CardContent className="p-4 text-center">
            {isCheckedOut ? (
              <>
                <CheckCircle className="w-8 h-8 text-rose-400 mx-auto mb-3" />
                <p className="text-gray-400 text-sm mb-1">Check Out</p>
                <p className="text-2xl font-bold text-white">
                  {format(new Date(isCheckedOut), 'HH:mm')}
                </p>
                <p className="text-rose-400 text-xs mt-1">Sudah check out</p>
              </>
            ) : (
              <>
                <LogOut className={`w-8 h-8 mx-auto mb-3 ${isCheckedIn ? 'text-amber-400' : 'text-gray-500'}`} />
                <p className="text-gray-400 text-sm mb-1">Check Out</p>
                <p className="text-gray-500">--:--</p>
                {isCheckedIn ? (
                  <Button
                    onClick={handleCheckOut}
                    disabled={loading}
                    className="mt-3 bg-gradient-to-r from-rose-500 to-pink-500 hover:from-rose-600 hover:to-pink-600 text-white"
                  >
                    {loading ? 'Memproses...' : 'Check Out'}
                  </Button>
                ) : (
                  <p className="text-gray-500 text-xs mt-3">Check in terlebih dahulu</p>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Work Hours Summary */}
      {isCheckedIn && isCheckedOut && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-4 p-4 rounded-xl bg-gradient-to-r from-purple-500/10 to-cyan-500/10 border border-white/10"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Clock className="w-5 h-5 text-purple-400" />
              <span className="text-gray-300">Total Jam Kerja Hari Ini</span>
            </div>
            <span className="text-xl font-bold text-white">
              {(() => {
                const diff = new Date(isCheckedOut).getTime() - new Date(isCheckedIn).getTime();
                const hours = Math.floor(diff / (1000 * 60 * 60));
                const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
                return `${hours}h ${minutes}m`;
              })()}
            </span>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
