'use client';

import { motion } from 'framer-motion';
import { useState, useMemo } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Search,
  ChevronLeft,
  ChevronRight,
  Filter,
  Edit2,
  Clock,
  Calendar,
  Download,
} from 'lucide-react';
import { format } from 'date-fns';
import { id } from 'date-fns/locale';

interface AttendanceRecord {
  id: string;
  userId: string;
  date: string;
  checkIn: string | null;
  checkOut: string | null;
  status: string;
  note: string | null;
  workHours: number | null;
  user: {
    id: string;
    name: string;
    email: string;
    position: string | null;
  };
}

interface AttendanceTableProps {
  attendance: AttendanceRecord[];
  onUpdate?: (id: string, data: any) => void;
  onExport?: () => void;
  isAdmin?: boolean;
}

const statusConfig: Record<string, { label: string; className: string }> = {
  hadir: { label: 'Hadir', className: 'border-emerald-500/50 text-emerald-400 bg-emerald-500/10' },
  izin: { label: 'Izin', className: 'border-amber-500/50 text-amber-400 bg-amber-500/10' },
  sakit: { label: 'Sakit', className: 'border-rose-500/50 text-rose-400 bg-rose-500/10' },
  alpa: { label: 'Alpa', className: 'border-gray-500/50 text-gray-400 bg-gray-500/10' },
};

export function AttendanceTable({ attendance, onUpdate, onExport, isAdmin = false }: AttendanceTableProps) {
  const [search, setSearch] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateFilter, setDateFilter] = useState({ start: '', end: '' });
  const [editDialog, setEditDialog] = useState<{ open: boolean; record: AttendanceRecord | null }>({
    open: false,
    record: null,
  });
  const [editForm, setEditForm] = useState({
    status: '',
    checkIn: '',
    checkOut: '',
    note: '',
  });

  const itemsPerPage = 10;

  const filteredAttendance = useMemo(() => {
    return attendance.filter((record) => {
      const matchesSearch =
        record.user.name.toLowerCase().includes(search.toLowerCase()) ||
        record.user.email.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = statusFilter === 'all' || record.status === statusFilter;
      
      let matchesDate = true;
      if (dateFilter.start && dateFilter.end) {
        const recordDate = new Date(record.date).toISOString().split('T')[0];
        matchesDate = recordDate >= dateFilter.start && recordDate <= dateFilter.end;
      }

      return matchesSearch && matchesStatus && matchesDate;
    });
  }, [attendance, search, statusFilter, dateFilter]);

  const paginatedAttendance = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return filteredAttendance.slice(start, start + itemsPerPage);
  }, [filteredAttendance, currentPage]);

  const totalPages = Math.ceil(filteredAttendance.length / itemsPerPage);

  const formatTime = (dateStr: string | null) => {
    if (!dateStr) return '-';
    try {
      return format(new Date(dateStr), 'HH:mm', { locale: id });
    } catch {
      return '-';
    }
  };

  const formatDate = (dateStr: string) => {
    try {
      return format(new Date(dateStr), 'd MMM yyyy', { locale: id });
    } catch {
      return '-';
    }
  };

  const handleEdit = (record: AttendanceRecord) => {
    setEditDialog({ open: true, record });
    setEditForm({
      status: record.status,
      checkIn: record.checkIn ? format(new Date(record.checkIn), 'HH:mm') : '',
      checkOut: record.checkOut ? format(new Date(record.checkOut), 'HH:mm') : '',
      note: record.note || '',
    });
  };

  const handleSaveEdit = async () => {
    if (!editDialog.record || !onUpdate) return;

    const date = new Date(editDialog.record.date);
    let checkIn = null;
    let checkOut = null;

    if (editForm.checkIn) {
      const [hours, minutes] = editForm.checkIn.split(':');
      checkIn = new Date(date);
      checkIn.setHours(parseInt(hours), parseInt(minutes), 0, 0);
    }

    if (editForm.checkOut) {
      const [hours, minutes] = editForm.checkOut.split(':');
      checkOut = new Date(date);
      checkOut.setHours(parseInt(hours), parseInt(minutes), 0, 0);
    }

    onUpdate(editDialog.record.id, {
      status: editForm.status,
      checkIn,
      checkOut,
      note: editForm.note,
    });

    setEditDialog({ open: false, record: null });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5 }}
      className="backdrop-blur-xl bg-white/5 border border-white/10 rounded-2xl p-6"
    >
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-6">
        <h3 className="text-lg font-semibold text-white">Rekap Absensi</h3>
        <div className="flex flex-col sm:flex-row gap-3 w-full lg:w-auto">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              placeholder="Cari karyawan..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setCurrentPage(1);
              }}
              className="pl-10 w-full sm:w-48 bg-white/5 border-white/10 text-white placeholder:text-gray-500"
            />
          </div>
          <Select value={statusFilter} onValueChange={(v) => { setStatusFilter(v); setCurrentPage(1); }}>
            <SelectTrigger className="w-full sm:w-36 bg-white/5 border-white/10 text-white">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent className="bg-slate-900 border-white/10">
              <SelectItem value="all">Semua</SelectItem>
              <SelectItem value="hadir">Hadir</SelectItem>
              <SelectItem value="izin">Izin</SelectItem>
              <SelectItem value="sakit">Sakit</SelectItem>
              <SelectItem value="alpa">Alpa</SelectItem>
            </SelectContent>
          </Select>
          <div className="flex gap-2">
            <Input
              type="date"
              value={dateFilter.start}
              onChange={(e) => setDateFilter(p => ({ ...p, start: e.target.value }))}
              className="w-full sm:w-36 bg-white/5 border-white/10 text-white"
            />
            <Input
              type="date"
              value={dateFilter.end}
              onChange={(e) => setDateFilter(p => ({ ...p, end: e.target.value }))}
              className="w-full sm:w-36 bg-white/5 border-white/10 text-white"
            />
          </div>
          {onExport && (
            <Button
              onClick={onExport}
              variant="outline"
              className="bg-white/5 border-white/10 text-white hover:bg-white/10"
            >
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
          )}
        </div>
      </div>

      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-white/10 hover:bg-white/5">
              <TableHead className="text-gray-400">Karyawan</TableHead>
              <TableHead className="text-gray-400">Tanggal</TableHead>
              <TableHead className="text-gray-400">Masuk</TableHead>
              <TableHead className="text-gray-400">Keluar</TableHead>
              <TableHead className="text-gray-400">Jam Kerja</TableHead>
              <TableHead className="text-gray-400">Status</TableHead>
              {isAdmin && <TableHead className="text-gray-400">Aksi</TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {paginatedAttendance.map((record, index) => (
              <motion.tr
                key={record.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.03 }}
                className="border-white/5 hover:bg-white/5 transition-colors"
              >
                <TableCell className="py-3">
                  <div>
                    <p className="text-white font-medium">{record.user.name}</p>
                    <p className="text-gray-500 text-sm">{record.user.position}</p>
                  </div>
                </TableCell>
                <TableCell className="py-3">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span className="text-gray-300">{formatDate(record.date)}</span>
                  </div>
                </TableCell>
                <TableCell className="py-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-emerald-500" />
                    <span className="text-gray-300">{formatTime(record.checkIn)}</span>
                  </div>
                </TableCell>
                <TableCell className="py-3">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-rose-500" />
                    <span className="text-gray-300">{formatTime(record.checkOut)}</span>
                  </div>
                </TableCell>
                <TableCell className="py-3">
                  <span className="text-gray-300">
                    {record.workHours ? `${record.workHours.toFixed(1)}h` : '-'}
                  </span>
                </TableCell>
                <TableCell className="py-3">
                  <Badge
                    variant="outline"
                    className={statusConfig[record.status]?.className || statusConfig.alpa.className}
                  >
                    {statusConfig[record.status]?.label || record.status}
                  </Badge>
                </TableCell>
                {isAdmin && (
                  <TableCell className="py-3">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(record)}
                      className="text-gray-400 hover:text-white hover:bg-white/10"
                    >
                      <Edit2 className="w-4 h-4" />
                    </Button>
                  </TableCell>
                )}
              </motion.tr>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Pagination */}
      <div className="flex items-center justify-between mt-6 pt-4 border-t border-white/10">
        <p className="text-sm text-gray-400">
          Menampilkan {((currentPage - 1) * itemsPerPage) + 1} - {Math.min(currentPage * itemsPerPage, filteredAttendance.length)} dari {filteredAttendance.length} data
        </p>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="bg-white/5 border-white/10 text-white hover:bg-white/10 disabled:opacity-50"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <span className="text-sm text-gray-400 px-3">
            {currentPage} / {totalPages}
          </span>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="bg-white/5 border-white/10 text-white hover:bg-white/10 disabled:opacity-50"
          >
            <ChevronRight className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* Edit Dialog */}
      <Dialog open={editDialog.open} onOpenChange={(open) => setEditDialog({ open, record: null })}>
        <DialogContent className="bg-slate-900 border-white/10 text-white">
          <DialogHeader>
            <DialogTitle>Edit Absensi</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-4">
            <div className="space-y-2">
              <Label className="text-gray-300">Status</Label>
              <Select value={editForm.status} onValueChange={(v) => setEditForm(p => ({ ...p, status: v }))}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-slate-900 border-white/10">
                  <SelectItem value="hadir">Hadir</SelectItem>
                  <SelectItem value="izin">Izin</SelectItem>
                  <SelectItem value="sakit">Sakit</SelectItem>
                  <SelectItem value="alpa">Alpa</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-300">Jam Masuk</Label>
                <Input
                  type="time"
                  value={editForm.checkIn}
                  onChange={(e) => setEditForm(p => ({ ...p, checkIn: e.target.value }))}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-300">Jam Keluar</Label>
                <Input
                  type="time"
                  value={editForm.checkOut}
                  onChange={(e) => setEditForm(p => ({ ...p, checkOut: e.target.value }))}
                  className="bg-white/5 border-white/10 text-white"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-300">Catatan</Label>
              <Textarea
                value={editForm.note}
                onChange={(e) => setEditForm(p => ({ ...p, note: e.target.value }))}
                className="bg-white/5 border-white/10 text-white"
                rows={3}
              />
            </div>
            <div className="flex justify-end gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => setEditDialog({ open: false, record: null })}
                className="bg-white/5 border-white/10 text-white hover:bg-white/10"
              >
                Batal
              </Button>
              <Button
                onClick={handleSaveEdit}
                className="bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700"
              >
                Simpan
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
}
