'use client';

import { motion } from 'framer-motion';
import { 
  Users, 
  UserCheck, 
  Clock, 
  TrendingUp,
  UserX,
  Calendar
} from 'lucide-react';

interface StatsCardsProps {
  stats: {
    totalEmployees: number;
    presentToday: number;
    lateToday: number;
    absentToday: number;
    avgWorkHours: number;
  };
}

export function StatsCards({ stats }: StatsCardsProps) {
  const cards = [
    {
      title: 'Total Karyawan',
      value: stats.totalEmployees,
      icon: Users,
      color: 'from-violet-500 to-purple-600',
      shadowColor: 'shadow-violet-500/30',
      change: '+2 bulan ini',
      changeType: 'positive',
    },
    {
      title: 'Hadir Hari Ini',
      value: stats.presentToday,
      icon: UserCheck,
      color: 'from-emerald-500 to-green-600',
      shadowColor: 'shadow-emerald-500/30',
      change: `${Math.round((stats.presentToday / stats.totalEmployees) * 100)}%`,
      changeType: 'positive',
    },
    {
      title: 'Terlambat',
      value: stats.lateToday,
      icon: Clock,
      color: 'from-amber-500 to-orange-600',
      shadowColor: 'shadow-amber-500/30',
      change: 'Hari ini',
      changeType: 'warning',
    },
    {
      title: 'Tidak Hadir',
      value: stats.absentToday,
      icon: UserX,
      color: 'from-rose-500 to-red-600',
      shadowColor: 'shadow-rose-500/30',
      change: 'Izin/Sakit/Alpa',
      changeType: 'negative',
    },
    {
      title: 'Rata-rata Jam Kerja',
      value: `${stats.avgWorkHours}h`,
      icon: TrendingUp,
      color: 'from-cyan-500 to-teal-600',
      shadowColor: 'shadow-cyan-500/30',
      change: 'Per hari',
      changeType: 'neutral',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
      {cards.map((card, index) => (
        <motion.div
          key={card.title}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.1 }}
          className="group relative"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-white/0 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
          <div className="relative backdrop-blur-xl bg-white/5 dark:bg-white/5 border border-white/10 rounded-2xl p-5 hover:border-white/20 transition-all duration-300 hover:shadow-xl">
            <div className="flex items-start justify-between mb-4">
              <div className={`p-3 rounded-xl bg-gradient-to-br ${card.color} ${card.shadowColor} shadow-lg`}>
                <card.icon className="w-5 h-5 text-white" />
              </div>
              <span className={`text-xs font-medium px-2 py-1 rounded-full ${
                card.changeType === 'positive' ? 'bg-emerald-500/20 text-emerald-400' :
                card.changeType === 'warning' ? 'bg-amber-500/20 text-amber-400' :
                card.changeType === 'negative' ? 'bg-rose-500/20 text-rose-400' :
                'bg-gray-500/20 text-gray-400'
              }`}>
                {card.change}
              </span>
            </div>
            <div>
              <p className="text-3xl font-bold text-white mb-1">{card.value}</p>
              <p className="text-sm text-gray-400">{card.title}</p>
            </div>
          </div>
        </motion.div>
      ))}
    </div>
  );
}
