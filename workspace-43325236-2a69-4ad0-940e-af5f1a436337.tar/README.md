# AttendX - Sistem Absensi Premium Dashboard

<div align="center">
  <img src="https://img.shields.io/badge/Next.js-16-black?style=for-the-badge&logo=next.js" alt="Next.js">
  <img src="https://img.shields.io/badge/TypeScript-5-blue?style=for-the-badge&logo=typescript" alt="TypeScript">
  <img src="https://img.shields.io/badge/Tailwind-4-cyan?style=for-the-badge&logo=tailwindcss" alt="Tailwind">
  <img src="https://img.shields.io/badge/Prisma-2D3748?style=for-the-badge&logo=prisma" alt="Prisma">
</div>

<div align="center">
  <h3>Dashboard Absensi Modern dengan Desain Glassmorphism</h3>
  <p>Sistem manajemen kehadiran karyawan yang elegan, responsif, dan powerful</p>
</div>

---

## 📸 Screenshots

### Login Page
Halaman login dengan desain glassmorphism yang modern dan animasi yang halus.

### Dashboard Admin
Tampilan dashboard admin dengan statistik real-time, grafik interaktif, dan manajemen karyawan.

### Dashboard Karyawan
Fitur check-in/out real-time dengan riwayat kehadiran pribadi.

---

## ✨ Fitur Utama

### 🔐 Autentikasi Multi-Role
- Login untuk Admin dan Karyawan
- Password hashing dengan bcryptjs
- Session management dengan Zustand persist

### 📊 Dashboard Admin
- **Statistik Cards** - Total karyawan, hadir, terlambat, tidak hadir, rata-rata jam kerja
- **Grafik Interaktif** - Area chart, Pie chart, Bar chart (dapat dipilih)
- **Daftar Karyawan** - Pencarian, filter posisi, pagination
- **Rekap Absensi** - Filter tanggal, status, pencarian
- **Edit Absensi** - Ubah status, jam masuk/keluar, catatan
- **Export Data** - Download CSV

### 👤 Dashboard Karyawan
- **Check In/Out** - Real-time clock dan button absensi
- **Riwayat Kehadiran** - Tabel absensi pribadi
- **Status Real-time** - Tampilan sudah check in/out dengan jam kerja

### 🎨 Fitur UI/UX
- **Dark Mode Toggle** - Mode terang dan gelap
- **Glassmorphism Design** - Desain modern dengan blur dan transparansi
- **Responsive Design** - Mobile dan desktop friendly
- **Smooth Animations** - Transisi halus dengan Framer Motion

---

## 🛠️ Tech Stack

| Category | Technology |
|----------|------------|
| **Framework** | Next.js 16 (App Router) |
| **Language** | TypeScript 5 |
| **Styling** | Tailwind CSS 4, shadcn/ui |
| **State Management** | Zustand |
| **Database** | Prisma ORM + SQLite |
| **Charts** | Recharts |
| **Animations** | Framer Motion |
| **Icons** | Lucide React |

---

## 🚀 Getting Started

### Prerequisites

- Node.js 18+ or Bun
- npm, yarn, or bun

### Installation

1. **Clone repository**
```bash
git clone https://github.com/username/attendx.git
cd attendx
```

2. **Install dependencies**
```bash
bun install
# or
npm install
```

3. **Setup environment variables**
```bash
# Create .env file
DATABASE_URL="file:./db/custom.db"
```

4. **Setup database**
```bash
bun run db:push
# or
npx prisma db push
```

5. **Seed database (optional - untuk data dummy)**
```bash
bunx tsx prisma/seed.ts
```

6. **Run development server**
```bash
bun run dev
# or
npm run dev
```

7. **Open browser**
```
http://localhost:3000
```

---

## 👤 Akun Demo

| Role | Email | Password |
|------|-------|----------|
| **Admin** | `admin@company.com` | `admin123` |
| **Karyawan** | `vina.nugraha0@company.com` | `password123` |

---

## 📁 Project Structure

```
attendx/
├── prisma/
│   ├── schema.prisma        # Database schema
│   └── seed.ts              # Seed data script
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── auth/
│   │   │   │   ├── login/route.ts
│   │   │   │   └── logout/route.ts
│   │   │   ├── attendance/route.ts
│   │   │   ├── stats/route.ts
│   │   │   └── users/route.ts
│   │   ├── globals.css
│   │   ├── layout.tsx
│   │   └── page.tsx
│   ├── components/
│   │   ├── dashboard/
│   │   │   ├── login-form.tsx
│   │   │   ├── sidebar.tsx
│   │   │   ├── header.tsx
│   │   │   ├── stats-cards.tsx
│   │   │   ├── attendance-chart.tsx
│   │   │   ├── employee-table.tsx
│   │   │   ├── attendance-table.tsx
│   │   │   ├── check-in-out.tsx
│   │   │   └── dashboard-content.tsx
│   │   └── ui/              # shadcn/ui components
│   ├── store/
│   │   └── auth-store.ts    # Zustand auth store
│   └── lib/
│       ├── db.ts            # Prisma client
│       └── utils.ts         # Utility functions
├── .env
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

---

## 📊 Database Schema

### User
```prisma
model User {
  id        String   @id @default(cuid())
  email     String   @unique
  password  String
  name      String
  role      String   @default("employee")  // "admin" or "employee"
  phone     String?
  position  String?
  avatar    String?
  isActive  Boolean  @default(true)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  attendances Attendance[]
}
```

### Attendance
```prisma
model Attendance {
  id           String   @id @default(cuid())
  userId       String
  user         User     @relation(fields: [userId], references: [id])
  date         DateTime @default(now())
  checkIn      DateTime?
  checkOut     DateTime?
  status       String   @default("pending")  // "hadir", "izin", "sakit", "alpa"
  note         String?
  workHours    Float?
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
  
  @@unique([userId, date])
}
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | Login user |
| POST | `/api/auth/logout` | Logout user |
| GET | `/api/users` | Get all users |
| GET | `/api/attendance` | Get attendance records |
| POST | `/api/attendance` | Create/Update attendance |
| PUT | `/api/attendance` | Update attendance |
| GET | `/api/stats` | Get dashboard statistics |

---

## 📝 Scripts

```bash
# Development
bun run dev          # Start development server

# Database
bun run db:push      # Push schema to database
bun run db:generate  # Generate Prisma client
bun run db:migrate   # Run migrations
bun run db:reset     # Reset database

# Code Quality
bun run lint         # Run ESLint
bun run build        # Build for production
```

---

## 🎯 Roadmap

- [ ] Notifikasi real-time dengan WebSocket
- [ ] Export ke PDF dengan formatting
- [ ] Approval workflow untuk izin/sakit
- [ ] Dashboard analytics lebih detail
- [ ] Mobile app dengan React Native
- [ ] Multi-language support (i18n)
- [ ] Integrasi dengan kalender
- [ ] Facial recognition untuk check-in

---

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 💖 Acknowledgments

- [shadcn/ui](https://ui.shadcn.com/) - Beautiful UI components
- [Lucide Icons](https://lucide.dev/) - Beautiful icons
- [Recharts](https://recharts.org/) - Composable charting library
- [Framer Motion](https://www.framer.com/motion/) - Production-ready animations

---

<div align="center">
  <p>Made with ❤️ by AttendX Team</p>
  <p>⭐ Star this repo if you find it useful! ⭐</p>
</div>
